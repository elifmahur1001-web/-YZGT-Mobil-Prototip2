const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const statsEl = document.getElementById("stats");
const missionEl = document.getElementById("mission");

function resize(){
  canvas.width = innerWidth * devicePixelRatio;
  canvas.height = innerHeight * devicePixelRatio;
  ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
}
addEventListener("resize",resize);
resize();

const world={w:2600,h:1800};
const keys={};
addEventListener("keydown",e=>{keys[e.code]=true;if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault();});
addEventListener("keyup",e=>keys[e.code]=false);

document.querySelectorAll("[data-key]").forEach(btn=>{
  const code=btn.dataset.key;
  const on=e=>{e.preventDefault();keys[code]=true};
  const off=e=>{e.preventDefault();keys[code]=false};
  btn.addEventListener("touchstart",on,{passive:false});
  btn.addEventListener("touchend",off,{passive:false});
  btn.addEventListener("touchcancel",off,{passive:false});
  btn.addEventListener("mousedown",on);
  btn.addEventListener("mouseup",off);
  btn.addEventListener("mouseleave",off);
});

const player={x:420,y:480,r:14,speed:3.2,health:100,money:0,inCar:null};
const car={x:620,y:520,w:54,h:28,angle:0,speed:0,maxSpeed:7,occupied:false};
const mission={x:2000,y:1250,r:34,done:false};
let wanted=0, policeTimer=0, eLatch=false, hornLatch=false;

const roads=[
  {x:0,y:400,w:world.w,h:170},
  {x:0,y:1100,w:world.w,h:180},
  {x:520,y:0,w:180,h:world.h},
  {x:1550,y:0,w:190,h:world.h}
];

const buildings=[];
for(let x=40;x<world.w-160;x+=270){
  for(let y=40;y<world.h-140;y+=230){
    const onRoad=roads.some(r=>x<r.x+r.w&&x+170>r.x&&y<r.y+r.h&&y+130>r.y);
    if(!onRoad) buildings.push({x,y,w:170,h:130});
  }
}

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function nearCar(){return dist(player,car)<70}

function update(){
  const up=keys.KeyW||keys.ArrowUp, down=keys.KeyS||keys.ArrowDown;
  const left=keys.KeyA||keys.ArrowLeft, right=keys.KeyD||keys.ArrowRight;

  if(keys.KeyE && !eLatch){
    eLatch=true;
    if(player.inCar){
      player.inCar.occupied=false;
      player.inCar=null;
      player.x=car.x+55*Math.cos(car.angle+Math.PI/2);
      player.y=car.y+55*Math.sin(car.angle+Math.PI/2);
    } else if(nearCar()){
      player.inCar=car;
      car.occupied=true;
    }
  }
  if(!keys.KeyE)eLatch=false;

  if(player.inCar){
    if(up)car.speed+=0.18;
    if(down)car.speed-=0.14;
    car.speed*=0.985;
    car.speed=clamp(car.speed,-3,car.maxSpeed);
    const steer=0.045*(Math.abs(car.speed)/car.maxSpeed+0.25);
    if(left)car.angle-=steer*Math.sign(car.speed||1);
    if(right)car.angle+=steer*Math.sign(car.speed||1);
    car.x+=Math.cos(car.angle)*car.speed;
    car.y+=Math.sin(car.angle)*car.speed;
    car.x=clamp(car.x,20,world.w-20);
    car.y=clamp(car.y,20,world.h-20);
    player.x=car.x;player.y=car.y;
    if(Math.abs(car.speed)>5.7)wanted=Math.max(wanted,1);
  }else{
    let dx=(right?1:0)-(left?1:0),dy=(down?1:0)-(up?1:0);
    if(dx||dy){const len=Math.hypot(dx,dy);player.x+=dx/len*player.speed;player.y+=dy/len*player.speed}
    player.x=clamp(player.x,10,world.w-10);player.y=clamp(player.y,10,world.h-10);
  }

  if(keys.Space && !hornLatch){hornLatch=true;wanted=Math.min(5,wanted+1)}
  if(!keys.Space)hornLatch=false;

  if(dist(player,mission)<mission.r+25 && !mission.done){
    mission.done=true;player.money+=500;wanted=0;
    missionEl.textContent="Görev tamamlandı! ₺500 kazandın.";
  }

  policeTimer++;
  if(policeTimer>900){wanted=Math.max(0,wanted-1);policeTimer=0}
  statsEl.textContent=`Can: ${player.health} | Para: ₺${player.money} | Aranma: ${"★".repeat(wanted)}${"☆".repeat(5-wanted)}`;
}

function drawRoad(r){
  ctx.fillStyle="#3b3f45";ctx.fillRect(r.x,r.y,r.w,r.h);
  ctx.strokeStyle="#e9d86b";ctx.lineWidth=4;ctx.setLineDash([28,24]);
  ctx.beginPath();
  if(r.w>r.h){ctx.moveTo(r.x,r.y+r.h/2);ctx.lineTo(r.x+r.w,r.y+r.h/2)}
  else{ctx.moveTo(r.x+r.w/2,r.y);ctx.lineTo(r.x+r.w/2,r.y+r.h)}
  ctx.stroke();ctx.setLineDash([]);
}

function draw(){
  const vw=innerWidth,vh=innerHeight;
  const target=player.inCar?car:player;
  const camX=clamp(target.x-vw/2,0,world.w-vw);
  const camY=clamp(target.y-vh/2,0,world.h-vh);
  ctx.clearRect(0,0,vw,vh);
  ctx.save();ctx.translate(-camX,-camY);

  ctx.fillStyle="#4f7a4e";ctx.fillRect(0,0,world.w,world.h);
  roads.forEach(drawRoad);

  buildings.forEach((b,i)=>{
    ctx.fillStyle=i%3===0?"#8c7563":i%3===1?"#6e7f8e":"#9b8f74";
    ctx.fillRect(b.x,b.y,b.w,b.h);
    ctx.fillStyle="rgba(255,235,160,.55)";
    for(let wx=b.x+18;wx<b.x+b.w-10;wx+=38)
      for(let wy=b.y+18;wy<b.y+b.h-10;wy+=34)ctx.fillRect(wx,wy,18,15);
  });

  if(!mission.done){
    const pulse=mission.r+Math.sin(performance.now()/180)*6;
    ctx.beginPath();ctx.arc(mission.x,mission.y,pulse,0,Math.PI*2);
    ctx.fillStyle="rgba(255,220,40,.35)";ctx.fill();
    ctx.beginPath();ctx.arc(mission.x,mission.y,10,0,Math.PI*2);
    ctx.fillStyle="#ffe331";ctx.fill();
  }

  ctx.save();ctx.translate(car.x,car.y);ctx.rotate(car.angle);
  ctx.fillStyle=car.occupied?"#1da1f2":"#d43f3a";ctx.fillRect(-car.w/2,-car.h/2,car.w,car.h);
  ctx.fillStyle="#a9d8f7";ctx.fillRect(-8,-car.h/2+3,22,car.h-6);
  ctx.fillStyle="#111";ctx.fillRect(-20,-18,12,6);ctx.fillRect(10,-18,12,6);ctx.fillRect(-20,12,12,6);ctx.fillRect(10,12,12,6);
  ctx.restore();

  if(!player.inCar){
    ctx.beginPath();ctx.arc(player.x,player.y,player.r,0,Math.PI*2);
    ctx.fillStyle="#f2c49b";ctx.fill();
    ctx.fillStyle="#202b55";ctx.fillRect(player.x-11,player.y+8,22,24);
  }

  if(wanted>0){
    ctx.fillStyle="#1f4ca1";
    for(let i=0;i<wanted;i++){
      const a=performance.now()/700+i*1.3;
      const px=player.x+Math.cos(a)*120,py=player.y+Math.sin(a)*120;
      ctx.fillRect(px-14,py-8,28,16);
    }
  }

  ctx.restore();

  const mapW=170,mapH=110,mx=innerWidth-mapW-12,my=12;
  ctx.fillStyle="rgba(0,0,0,.65)";ctx.fillRect(mx,my,mapW,mapH);
  ctx.fillStyle="#596168";
  roads.forEach(r=>ctx.fillRect(mx+r.x/world.w*mapW,my+r.y/world.h*mapH,r.w/world.w*mapW,r.h/world.h*mapH));
  ctx.fillStyle="#4dd0ff";ctx.fillRect(mx+target.x/world.w*mapW-3,my+target.y/world.h*mapH-3,6,6);
  if(!mission.done){ctx.fillStyle="#ffe331";ctx.fillRect(mx+mission.x/world.w*mapW-3,my+mission.y/world.h*mapH-3,6,6)}
}

function loop(){update();draw();requestAnimationFrame(loop)}
loop();
