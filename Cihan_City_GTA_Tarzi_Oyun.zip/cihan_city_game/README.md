# Cihan City

Tarayıcıda çalışan küçük GTA tarzı açık dünya prototipi.

## Çalıştırma
1. ZIP dosyasını aç.
2. `index.html` dosyasına dokun veya bilgisayarda çift tıkla.
3. Mobil cihazlarda mümkünse dosyaları GitHub Pages / Netlify gibi bir servise yükle.

## Kontroller
- WASD veya ok tuşları: hareket / araç sürme
- E: araca binme veya araçtan inme
- Boşluk: korna
- Telefonda ekrandaki düğmeler

## Özellikler
- Açık harita
- Yaya hareketi
- Araca binme ve sürüş
- Görev noktası
- Para sistemi
- Basit aranma/polis sistemi
- Mobil kontroller
