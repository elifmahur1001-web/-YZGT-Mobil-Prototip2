# GÖKALP FPV Drone Simülatörü

Tarayıcıda çalışan, bağımsız bir FPV drone simülasyonu prototipidir.

## Çalıştırma

1. Klasörü bilgisayarınıza çıkarın.
2. `index.html` dosyasına çift tıklayın.
3. Drone seçin ve **Motorları Çalıştır** düğmesine basın.

Ek kurulum veya internet bağlantısı gerekmez.

## Kontroller

- `W / S`: İleri ve geri eğim
- `A / D`: Sağ ve sol yatış
- `Q / E`: Yön dönüşü
- `SPACE`: Gaz artırma
- `SHIFT`: Gaz azaltma
- `R`: Uçuşu sıfırlama

## Özellikler

- Üç farklı FPV drone profili
- Gerçek zamanlı üretilen motor sesi
- Gaz, yük ve hıza göre değişen motor tonu
- FPV HUD
- Hız, irtifa, mesafe, batarya ve sinyal göstergeleri
- Basit uçuş fiziği
- Prosedürel arazi ve uzaklık hissi
- Düşük batarya uyarısı
- Tamamen çevrimdışı çalışma

## Sonraki geliştirmeler

- USB oyun kolu / RC kumanda desteği
- Gerçek 3D arazi
- Engel çarpışması
- FPV yarış parkuru
- Görev sistemi
- Kamera kayıt sistemi
- Drone özelleştirme ekranı
