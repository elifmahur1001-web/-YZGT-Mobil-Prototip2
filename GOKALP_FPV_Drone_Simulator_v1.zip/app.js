(() => {
  "use strict";

  const canvas = document.getElementById("simCanvas");
  const ctx = canvas.getContext("2d");

  const ui = {
    startScreen: document.getElementById("startScreen"),
    startBtn: document.getElementById("startBtn"),
    hud: document.getElementById("hud"),
    menuBtn: document.getElementById("menuBtn"),
    speed: document.getElementById("speedValue"),
    altitude: document.getElementById("altitudeValue"),
    distance: document.getElementById("distanceValue"),
    battery: document.getElementById("batteryValue"),
    batteryFill: document.getElementById("batteryFill"),
    throttle: document.getElementById("throttleValue"),
    signal: document.getElementById("signalValue"),
    timer: document.getElementById("timerValue"),
    heading: document.getElementById("headingValue"),
    droneName: document.getElementById("droneName"),
    horizon: document.getElementById("horizonLine"),
    warning: document.getElementById("warning")
  };

  const DRONES = {
    scout: {
      name: "ŞAHİN S1",
      maxSpeed: 31,
      agility: 1.0,
      lift: 1.0,
      batteryDrain: 1.0,
      motorTone: 88
    },
    racer: {
      name: "AKIN R5",
      maxSpeed: 46,
      agility: 1.35,
      lift: 1.15,
      batteryDrain: 1.35,
      motorTone: 112
    },
    heavy: {
      name: "KARTAL H2",
      maxSpeed: 24,
      agility: 0.72,
      lift: 1.22,
      batteryDrain: 0.88,
      motorTone: 70
    }
  };

  let selectedDrone = "scout";
  let drone = DRONES[selectedDrone];
  let running = false;
  let lastTime = 0;
  let startTime = 0;

  const keys = new Set();

  const state = {
    x: 0,
    y: 8,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    pitch: 0,
    roll: 0,
    yaw: 0,
    throttle: 0.58,
    battery: 100,
    distance: 0,
    signal: 100
  };

  let audioCtx = null;
  let masterGain = null;
  let motorOsc1 = null;
  let motorOsc2 = null;
  let noiseSource = null;
  let noiseGain = null;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(innerWidth * dpr);
    canvas.height = Math.floor(innerHeight * dpr);
    canvas.style.width = `${innerWidth}px`;
    canvas.style.height = `${innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function resetState() {
    Object.assign(state, {
      x: 0, y: 8, z: 0,
      vx: 0, vy: 0, vz: 0,
      pitch: 0, roll: 0, yaw: 0,
      throttle: 0.58,
      battery: 100,
      distance: 0,
      signal: 100
    });
    startTime = performance.now();
  }

  function startAudio() {
    if (audioCtx) {
      audioCtx.resume();
      return;
    }

    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = 0.10;
    masterGain.connect(audioCtx.destination);

    motorOsc1 = audioCtx.createOscillator();
    motorOsc2 = audioCtx.createOscillator();
    const gain1 = audioCtx.createGain();
    const gain2 = audioCtx.createGain();

    motorOsc1.type = "sawtooth";
    motorOsc2.type = "square";
    gain1.gain.value = 0.48;
    gain2.gain.value = 0.10;

    motorOsc1.connect(gain1).connect(masterGain);
    motorOsc2.connect(gain2).connect(masterGain);

    const bufferSize = audioCtx.sampleRate * 2;
    const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;
    noiseGain = audioCtx.createGain();
    noiseGain.gain.value = 0.015;
    noiseSource.connect(noiseGain).connect(masterGain);

    motorOsc1.start();
    motorOsc2.start();
    noiseSource.start();
  }

  function updateAudio() {
    if (!audioCtx || !running) return;
    const load = Math.hypot(state.vx, state.vz) / drone.maxSpeed;
    const base = drone.motorTone + state.throttle * 310 + load * 55;
    const t = audioCtx.currentTime;
    motorOsc1.frequency.setTargetAtTime(base, t, 0.03);
    motorOsc2.frequency.setTargetAtTime(base * 1.99, t, 0.03);
    masterGain.gain.setTargetAtTime(0.055 + state.throttle * 0.13, t, 0.04);
    noiseGain.gain.setTargetAtTime(0.008 + load * 0.025, t, 0.08);
  }

  function stopAudioSoft() {
    if (masterGain && audioCtx) {
      masterGain.gain.setTargetAtTime(0.0001, audioCtx.currentTime, 0.08);
    }
  }

  function startFlight() {
    drone = DRONES[selectedDrone];
    ui.droneName.textContent = drone.name;
    resetState();
    startAudio();
    running = true;
    ui.startScreen.classList.add("hidden");
    ui.hud.classList.remove("hidden");
    lastTime = performance.now();
    requestAnimationFrame(loop);
  }

  function stopFlight() {
    running = false;
    stopAudioSoft();
    ui.startScreen.classList.remove("hidden");
    ui.hud.classList.add("hidden");
  }

  document.querySelectorAll(".drone-card").forEach(card => {
    card.addEventListener("click", () => {
      document.querySelectorAll(".drone-card").forEach(c => c.classList.remove("selected"));
      card.classList.add("selected");
      selectedDrone = card.dataset.drone;
    });
  });

  ui.startBtn.addEventListener("click", startFlight);
  ui.menuBtn.addEventListener("click", stopFlight);

  addEventListener("keydown", event => {
    const key = event.key.toLowerCase();
    if (["w","a","s","d","q","e","r","shift"," "].includes(key)) {
      event.preventDefault();
    }
    keys.add(key);
    if (key === "r" && running) resetState();
  });

  addEventListener("keyup", event => {
    keys.delete(event.key.toLowerCase());
  });

  function update(dt) {
    const pitchInput = (keys.has("w") ? 1 : 0) - (keys.has("s") ? 1 : 0);
    const rollInput = (keys.has("d") ? 1 : 0) - (keys.has("a") ? 1 : 0);
    const yawInput = (keys.has("e") ? 1 : 0) - (keys.has("q") ? 1 : 0);
    const throttleInput = (keys.has(" ") ? 1 : 0) - (keys.has("shift") ? 1 : 0);

    state.throttle += throttleInput * dt * 0.42;
    state.throttle = clamp(state.throttle, 0.0, 1.0);

    const response = drone.agility * 2.6;
    state.pitch = approach(state.pitch, pitchInput * 0.55, response * dt);
    state.roll = approach(state.roll, rollInput * 0.62, response * dt);
    state.yaw += yawInput * drone.agility * 1.45 * dt;

    if (!pitchInput) state.pitch *= Math.pow(0.10, dt);
    if (!rollInput) state.roll *= Math.pow(0.10, dt);

    const forwardX = Math.sin(state.yaw);
    const forwardZ = Math.cos(state.yaw);
    const rightX = Math.cos(state.yaw);
    const rightZ = -Math.sin(state.yaw);

    const forwardForce = state.pitch * drone.maxSpeed * 1.9;
    const sideForce = state.roll * drone.maxSpeed * 1.55;

    state.vx += (forwardX * forwardForce + rightX * sideForce) * dt;
    state.vz += (forwardZ * forwardForce + rightZ * sideForce) * dt;

    const liftForce = (state.throttle - 0.50) * 20 * drone.lift;
    state.vy += liftForce * dt;
    state.vy -= 1.15 * dt;

    const horizontalSpeed = Math.hypot(state.vx, state.vz);
    const maxSpeed = drone.maxSpeed;
    if (horizontalSpeed > maxSpeed) {
      const scale = maxSpeed / horizontalSpeed;
      state.vx *= scale;
      state.vz *= scale;
    }

    const horizontalDrag = Math.pow(0.34, dt);
    state.vx *= horizontalDrag;
    state.vz *= horizontalDrag;
    state.vy *= Math.pow(0.46, dt);

    const oldX = state.x;
    const oldZ = state.z;
    state.x += state.vx * dt;
    state.z += state.vz * dt;
    state.y += state.vy * dt;

    if (state.y < 1.2) {
      state.y = 1.2;
      if (state.vy < 0) state.vy *= -0.18;
      state.vx *= 0.87;
      state.vz *= 0.87;
    }

    state.distance += Math.hypot(state.x - oldX, state.z - oldZ);
    state.signal = clamp(100 - state.distance * 0.015, 18, 100);

    const drain = (0.22 + state.throttle * 0.9 + horizontalSpeed / maxSpeed * 0.35)
      * drone.batteryDrain * dt;
    state.battery = Math.max(0, state.battery - drain);

    if (state.battery <= 0) {
      state.throttle = 0;
    }

    updateAudio();
    updateHud(horizontalSpeed);
  }

  function updateHud(horizontalSpeed) {
    ui.speed.textContent = Math.round(horizontalSpeed * 3.6);
    ui.altitude.textContent = Math.round(state.y);
    ui.distance.textContent = Math.round(state.distance);
    ui.battery.textContent = Math.round(state.battery);
    ui.batteryFill.style.width = `${state.battery}%`;
    ui.batteryFill.style.background = state.battery < 20 ? "#ff5d67" : "#83ffd4";
    ui.throttle.textContent = Math.round(state.throttle * 100);
    ui.signal.textContent = Math.round(state.signal);

    const elapsed = Math.floor((performance.now() - startTime) / 1000);
    const minutes = String(Math.floor(elapsed / 60)).padStart(2, "0");
    const seconds = String(elapsed % 60).padStart(2, "0");
    ui.timer.textContent = `${minutes}:${seconds}`;

    const heading = ((state.yaw * 180 / Math.PI) % 360 + 360) % 360;
    ui.heading.textContent = `${String(Math.round(heading)).padStart(3, "0")}°`;

    ui.horizon.style.transform =
      `translate(-50%, -50%) translateY(${state.pitch * 75}px) rotate(${-state.roll * 38}deg)`;

    ui.warning.classList.toggle("hidden", state.battery >= 20);
  }

  function draw() {
    const w = innerWidth;
    const h = innerHeight;
    const horizonY = h * 0.46 + state.pitch * 105;

    const sky = ctx.createLinearGradient(0, 0, 0, horizonY);
    sky.addColorStop(0, "#244f69");
    sky.addColorStop(1, "#8ab2c2");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, Math.max(0, horizonY));

    const ground = ctx.createLinearGradient(0, horizonY, 0, h);
    ground.addColorStop(0, "#596c52");
    ground.addColorStop(0.35, "#334934");
    ground.addColorStop(1, "#111c18");
    ctx.fillStyle = ground;
    ctx.fillRect(0, horizonY, w, h - horizonY);

    drawMountains(w, horizonY);
    drawGroundGrid(w, h, horizonY);
    drawObjects(w, h, horizonY);

    const vignette = ctx.createRadialGradient(
      w / 2, h / 2, Math.min(w, h) * 0.18,
      w / 2, h / 2, Math.max(w, h) * 0.72
    );
    vignette.addColorStop(0, "rgba(0,0,0,0)");
    vignette.addColorStop(1, "rgba(0,0,0,0.58)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = "rgba(255,255,255,0.025)";
    for (let y = 0; y < h; y += 4) {
      ctx.fillRect(0, y, w, 1);
    }
  }

  function drawMountains(w, horizonY) {
    ctx.save();
    ctx.translate(w / 2, horizonY);
    ctx.rotate(-state.roll * 0.24);

    const offset = ((state.yaw * 90) % 260);
    ctx.beginPath();
    ctx.moveTo(-w, 50);

    for (let x = -w; x <= w; x += 70) {
      const ridge = Math.sin((x + offset) * 0.012) * 28
        + Math.sin((x + offset) * 0.031) * 12;
      ctx.lineTo(x, -25 - ridge);
    }

    ctx.lineTo(w, 90);
    ctx.closePath();
    ctx.fillStyle = "#324a47";
    ctx.fill();
    ctx.restore();
  }

  function drawGroundGrid(w, h, horizonY) {
    ctx.save();
    ctx.translate(w / 2, horizonY);
    ctx.rotate(-state.roll * 0.33);

    const speedShift = (state.z * 5) % 48;
    ctx.strokeStyle = "rgba(205,255,230,0.12)";
    ctx.lineWidth = 1;

    for (let i = 0; i < 18; i++) {
      const t = i / 18;
      const y = Math.pow(t, 2.25) * (h - horizonY) + speedShift * t;
      ctx.beginPath();
      ctx.moveTo(-w, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const vanishingX = -state.roll * 180;
    for (let i = -12; i <= 12; i++) {
      const x = i * 95 - ((state.x * 2.5) % 95);
      ctx.beginPath();
      ctx.moveTo(vanishingX, 0);
      ctx.lineTo(x, h - horizonY + 100);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawObjects(w, h, horizonY) {
    const objects = [
      { x: 160, z: 240, type: "tower" },
      { x: -220, z: 330, type: "tree" },
      { x: 70, z: 480, type: "tree" },
      { x: -80, z: 180, type: "gate" },
      { x: 340, z: 560, type: "tower" },
      { x: -420, z: 690, type: "tree" }
    ];

    for (const obj of objects) {
      const dx = obj.x - state.x;
      const dz = obj.z - state.z;
      const sin = Math.sin(-state.yaw);
      const cos = Math.cos(-state.yaw);
      const camX = dx * cos - dz * sin;
      const camZ = dx * sin + dz * cos;

      if (camZ < 8) continue;

      const scale = 520 / camZ;
      const screenX = w / 2 + camX * scale;
      const baseY = horizonY + (state.y * 24) * scale;
      if (screenX < -120 || screenX > w + 120) continue;

      ctx.save();
      ctx.translate(screenX, baseY);
      ctx.rotate(-state.roll * 0.22);

      if (obj.type === "tree") {
        ctx.fillStyle = "#17291b";
        ctx.fillRect(-4 * scale, -40 * scale, 8 * scale, 40 * scale);
        ctx.beginPath();
        ctx.arc(0, -52 * scale, 22 * scale, 0, Math.PI * 2);
        ctx.fillStyle = "#243f2a";
        ctx.fill();
      } else if (obj.type === "tower") {
        ctx.strokeStyle = "#223028";
        ctx.lineWidth = Math.max(1, 3 * scale);
        ctx.beginPath();
        ctx.moveTo(-12 * scale, 0);
        ctx.lineTo(0, -85 * scale);
        ctx.lineTo(12 * scale, 0);
        ctx.moveTo(-8 * scale, -25 * scale);
        ctx.lineTo(8 * scale, -25 * scale);
        ctx.moveTo(-5 * scale, -50 * scale);
        ctx.lineTo(5 * scale, -50 * scale);
        ctx.stroke();
      } else {
        ctx.strokeStyle = "#28382f";
        ctx.lineWidth = Math.max(1, 4 * scale);
        ctx.strokeRect(-28 * scale, -32 * scale, 56 * scale, 32 * scale);
      }
      ctx.restore();
    }
  }

  function approach(current, target, amount) {
    if (current < target) return Math.min(current + amount, target);
    return Math.max(current - amount, target);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function loop(now) {
    if (!running) return;
    const dt = Math.min((now - lastTime) / 1000, 0.033);
    lastTime = now;
    update(dt);
    draw();
    requestAnimationFrame(loop);
  }

  resize();
  draw();
  addEventListener("resize", resize);
})();
